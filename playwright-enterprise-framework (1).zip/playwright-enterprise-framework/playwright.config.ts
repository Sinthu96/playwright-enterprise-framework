import 'dotenv/config';
import { defineConfig, devices } from '@playwright/test';
import { env } from './config/env';

const isCI = env.CI;
const workers = env.WORKERS;

export default defineConfig({
  testDir: './tests',
  outputDir: './test-results',
  fullyParallel: true,
  forbidOnly: isCI,
  retries: env.RETRIES,
  workers: isCI ? (workers ?? 2) : (workers ?? undefined),
  timeout: 30_000,
  expect: { timeout: 5_000 },
  globalTimeout: 0,
  reporter: [
    ['list'],
    ['junit', { outputFile: 'test-results/junit/results.xml' }],
    ['allure-playwright', {
      resultsDir: 'allure-results',
      detail: true,
      suiteTitle: false,
      environmentInfo: {
        nodeVersion: process.version,
        platform: process.platform,
      },
    }],
  ],
  use: {
    baseURL: env.BASE_URL,
    actionTimeout: env.ACTION_TIMEOUT_MS,
    navigationTimeout: env.NAVIGATION_TIMEOUT_MS,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    ignoreHTTPSErrors: false,
    acceptDownloads: true,
    locale: 'en-US',
    timezoneId: 'UTC',
    colorScheme: 'light',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
  ],
});
