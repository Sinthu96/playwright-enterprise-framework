import 'dotenv/config';
import { z } from 'zod';

const booleanFromEnv = z
  .union([z.boolean(), z.string()])
  .transform((value) => {
    if (typeof value === 'boolean') return value;
    return ['true', '1', 'yes'].includes(value.toLowerCase());
  });

const nonNegativeInteger = (fallback: number) =>
  z.string().optional().transform((value) => {
    if (value === undefined || value.trim() === '') return fallback;
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed < 0) {
      throw new Error(`Expected a non-negative integer, received "${value}"`);
    }
    return parsed;
  });

const schema = z.object({
  BASE_URL: z.string().url().default('https://www.saucedemo.com'),
  API_BASE_URL: z.string().url().optional(),
  TEST_USERNAME: z.string().default('standard_user'),
  TEST_PASSWORD: z.string().default('secret_sauce'),
  LOCKED_OUT_USERNAME: z.string().default('locked_out_user'),
  CI: booleanFromEnv.default(false),
  WORKERS: nonNegativeInteger(0),
  RETRIES: nonNegativeInteger(0),
  ACTION_TIMEOUT_MS: nonNegativeInteger(10_000),
  NAVIGATION_TIMEOUT_MS: nonNegativeInteger(30_000),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  const details = parsed.error.issues
    .map((issue) => `${issue.path.join('.') || 'environment'}: ${issue.message}`)
    .join('\n');
  throw new Error(`Invalid environment configuration:\n${details}`);
}

export const env = Object.freeze({
  ...parsed.data,
  WORKERS: parsed.data.WORKERS === 0 ? undefined : parsed.data.WORKERS,
});
