export const TAGS = {
  smoke: '@smoke',
  regression: '@regression',
  api: '@api',
  ui: '@ui',
} as const;

export type TestTag = (typeof TAGS)[keyof typeof TAGS];
