export interface TestUser {
  username: string;
  email: string;
  displayName: string;
}

export function createTestUser(overrides: Partial<TestUser> = {}): TestUser {
  const id = crypto.randomUUID();
  return {
    username: `test-${id}`,
    email: `test-${id}@example.invalid`,
    displayName: `Automation User ${id.slice(0, 8)}`,
    ...overrides,
  };
}
