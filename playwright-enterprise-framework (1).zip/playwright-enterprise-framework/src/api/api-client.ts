import type { APIRequestContext, APIResponse } from '@playwright/test';
import type { RequestOptions } from '../types/api';

export class ApiClient {
  public constructor(
    private readonly request: APIRequestContext,
    private readonly baseUrl: string,
    private readonly defaultHeaders: Record<string, string> = {},
  ) {}

  public get(path: string, options: RequestOptions = {}): Promise<APIResponse> {
    return this.request.get(this.url(path), {
      headers: { ...this.defaultHeaders, ...options.headers },
      ...(options.timeout !== undefined ? { timeout: options.timeout } : {}),
    });
  }

  public post<TBody>(
    path: string,
    data: TBody,
    options: RequestOptions = {},
  ): Promise<APIResponse> {
    return this.request.post(this.url(path), {
      data,
      headers: { ...this.defaultHeaders, ...options.headers },
      ...(options.timeout !== undefined ? { timeout: options.timeout } : {}),
    });
  }

  public put<TBody>(
    path: string,
    data: TBody,
    options: RequestOptions = {},
  ): Promise<APIResponse> {
    return this.request.put(this.url(path), {
      data,
      headers: { ...this.defaultHeaders, ...options.headers },
      ...(options.timeout !== undefined ? { timeout: options.timeout } : {}),
    });
  }

  public delete(path: string, options: RequestOptions = {}): Promise<APIResponse> {
    return this.request.delete(this.url(path), {
      headers: { ...this.defaultHeaders, ...options.headers },
      ...(options.timeout !== undefined ? { timeout: options.timeout } : {}),
    });
  }

  private url(path: string): string {
    return new URL(path.replace(/^\/+/, ''), `${this.baseUrl.replace(/\/+$/, '')}/`).toString();
  }
}
