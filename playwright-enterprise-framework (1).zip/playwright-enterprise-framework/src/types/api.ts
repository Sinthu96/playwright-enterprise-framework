export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}

export interface HealthResponse {
  status: 'ok' | 'degraded';
  timestamp?: string;
}

export interface RequestOptions {
  headers?: Record<string, string>;
  timeout?: number;
}
