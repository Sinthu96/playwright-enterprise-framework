import type { Page } from '@playwright/test';

export class NavigationWorkflow {
  public constructor(private readonly page: Page) {}

  public async navigateTo(path: string): Promise<void> {
    await this.page.goto(path);
  }
}
