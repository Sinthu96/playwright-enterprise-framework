import { test as base, expect } from '@playwright/test';
import { env } from '../../config/env';
import { ApiClient } from '../api/api-client';
import { CartPage } from '../pages/cart.page';
import { CheckoutPage } from '../pages/checkout.page';
import { InventoryPage } from '../pages/inventory.page';
import { LoginPage } from '../pages/login.page';

type FrameworkFixtures = {
  loginPage: LoginPage;
  inventoryPage: InventoryPage;
  cartPage: CartPage;
  checkoutPage: CheckoutPage;
  apiClient: ApiClient | undefined;
  loginAsStandardUser: () => Promise<void>;
};

export const test = base.extend<FrameworkFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  inventoryPage: async ({ page }, use) => {
    await use(new InventoryPage(page));
  },

  cartPage: async ({ page }, use) => {
    await use(new CartPage(page));
  },

  checkoutPage: async ({ page }, use) => {
    await use(new CheckoutPage(page));
  },

  apiClient: async ({ request }, use) => {
    const client = env.API_BASE_URL ? new ApiClient(request, env.API_BASE_URL) : undefined;
    await use(client);
  },

  loginAsStandardUser: async ({ loginPage, inventoryPage }, use) => {
    await use(async () => {
      await loginPage.openLogin();
      await loginPage.login(env.TEST_USERNAME, env.TEST_PASSWORD);
      await inventoryPage.expectLoaded();
    });
  },
});

export { expect };
