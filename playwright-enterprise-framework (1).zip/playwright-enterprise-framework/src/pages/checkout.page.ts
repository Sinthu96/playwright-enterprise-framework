import { expect, type Page } from '@playwright/test';
import { BasePage } from './base.page';

export class CheckoutPage extends BasePage {
  public readonly firstName = this.page.getByTestId('firstName');
  public readonly lastName = this.page.getByTestId('lastName');
  public readonly postalCode = this.page.getByTestId('postalCode');
  public readonly continueButton = this.page.getByTestId('continue');
  public readonly finishButton = this.page.getByTestId('finish');
  public readonly errorMessage = this.page.getByTestId('error');
  public readonly completeHeader = this.page.getByTestId('complete-header');

  public constructor(page: Page) {
    super(page);
  }

  public async fillCustomerDetails(first: string, last: string, postal: string): Promise<void> {
    await this.firstName.fill(first);
    await this.lastName.fill(last);
    await this.postalCode.fill(postal);
  }

  public async expectOrderComplete(): Promise<void> {
    await expect(this.page).toHaveURL(/checkout-complete\.html$/);
    await expect(this.completeHeader).toHaveText('Thank you for your order!');
  }
}
