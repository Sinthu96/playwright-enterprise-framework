import { expect, type Page } from '@playwright/test';
import { BasePage } from './base.page';

export class LoginPage extends BasePage {
  public readonly usernameInput = this.page.getByTestId('username');
  public readonly passwordInput = this.page.getByTestId('password');
  public readonly loginButton = this.page.getByTestId('login-button');
  public readonly errorMessage = this.page.getByTestId('error');

  public constructor(page: Page) {
    super(page);
  }

  public async openLogin(): Promise<void> {
    await this.open('/');
    await expect(this.loginButton).toBeVisible();
  }

  public async login(username: string, password: string): Promise<void> {
    await this.usernameInput.fill(username);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }
}
