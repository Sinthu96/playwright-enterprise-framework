import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from './base.page';

export class InventoryPage extends BasePage {
  public readonly title = this.page.getByTestId('title');
  public readonly items = this.page.getByTestId('inventory-item');
  public readonly cartLink = this.page.getByTestId('shopping-cart-link');
  public readonly cartBadge = this.page.getByTestId('shopping-cart-badge');
  public readonly menuButton = this.page.getByRole('button', { name: 'Open Menu' });
  public readonly logoutLink = this.page.getByTestId('logout-sidebar-link');

  public constructor(page: Page) {
    super(page);
  }

  public async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/inventory\.html$/);
    await expect(this.title).toHaveText('Products');
    await expect(this.items).toHaveCount(6);
  }

  public product(name: string): Locator {
    return this.items.filter({ has: this.page.getByText(name, { exact: true }) });
  }

  public async addProductToCart(name: string): Promise<void> {
    const product = this.product(name);
    await expect(product).toHaveCount(1);
    await product.getByRole('button', { name: 'Add to cart' }).click();
  }

  public async openCart(): Promise<void> {
    await this.cartLink.click();
  }
}
