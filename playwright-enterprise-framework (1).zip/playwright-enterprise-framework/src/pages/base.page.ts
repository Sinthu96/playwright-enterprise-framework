import type { Page } from '@playwright/test';

export abstract class BasePage {
  protected constructor(protected readonly page: Page) {}

  public async open(path = '/'): Promise<void> {
    await this.page.goto(path);
  }

  public currentUrl(): string {
    return this.page.url();
  }
}
