import { expect, type Page } from '@playwright/test';
import { BasePage } from './base.page';

export class CartPage extends BasePage {
  public readonly title = this.page.getByTestId('title');
  public readonly items = this.page.getByTestId('inventory-item');
  public readonly checkoutButton = this.page.getByTestId('checkout');
  public readonly continueShoppingButton = this.page.getByTestId('continue-shopping');

  public constructor(page: Page) {
    super(page);
  }

  public async expectContainsProduct(name: string): Promise<void> {
    await expect(this.items.filter({ hasText: name })).toHaveCount(1);
  }

  public async checkout(): Promise<void> {
    await this.checkoutButton.click();
  }
}
