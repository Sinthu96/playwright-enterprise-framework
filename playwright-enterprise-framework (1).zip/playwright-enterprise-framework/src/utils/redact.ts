const SENSITIVE_KEYS = /password|token|secret|authorization|cookie|api[-_]?key/i;

export function redactObject<T>(input: T): T {
  if (Array.isArray(input)) {
    return input.map((value) => redactObject(value)) as T;
  }
  if (input !== null && typeof input === 'object') {
    const output: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(input)) {
      output[key] = SENSITIVE_KEYS.test(key) ? '[REDACTED]' : redactObject(value);
    }
    return output as T;
  }
  return input;
}
