import type { Locator, Page } from '@playwright/test';

export class HeaderComponent {
  public readonly root: Locator;

  public constructor(page: Page, root: Locator = page.getByRole('banner')) {
    this.root = root;
  }

  public link(name: string): Locator {
    return this.root.getByRole('link', { name });
  }
}
