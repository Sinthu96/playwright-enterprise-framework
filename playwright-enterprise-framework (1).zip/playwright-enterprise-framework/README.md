# Playwright Enterprise Test Automation Framework

A reusable Playwright + TypeScript framework using a hybrid page-object/fixture/service architecture, Allure reporting, and Jenkins CI/CD. It is preconfigured for the public Sauce Demo practice store.

## Application under test

- Site: https://www.saucedemo.com/
- Standard demo user: `standard_user`
- Demo password: `secret_sauce`
- Locked-out demo user: `locked_out_user`

These are publicly documented demo credentials, not private credentials. Use them only on the demo site.

## Requirements

- Node.js 20 or newer
- npm
- Git
- For browser tests: Playwright-supported operating system libraries
- Jenkins: Node/npm-capable agent and the Allure Jenkins plugin for publishing Allure reports

## Quick start

```bash
npm install
cp .env.example .env
npx playwright install
npm run validate:env
npm run typecheck
npm run lint
npx playwright test --project=chromium
```

The default `BASE_URL` is Sauce Demo. Public demo sites can change or experience downtime, so a failed run may reflect an external site issue rather than a framework defect.

## Scenarios included

- Successful login with the standard demo user
- Rejection of invalid credentials
- Locked-out account validation
- Product inventory assertions
- Add a product to the shopping cart and verify the cart badge
- Complete the checkout journey
- Validate required checkout fields
- Optional API health test, skipped unless `API_BASE_URL` is configured
- Deterministic mocked API response test

## Project layout

```text
config/                 Typed environment configuration and tags
src/api/                Reusable API client
src/components/          Reusable UI components
src/data/factories/      Test-data builders
src/fixtures/            Extended Playwright fixtures
src/pages/               Login, inventory, cart, checkout page objects
src/types/               Shared domain types
src/utils/               Shared utilities
src/workflows/           Reusable user journeys
tests/ui/                Authentication and shopping-flow tests
tests/api/               Optional API tests
tests/integration/       UI/API interception tests
scripts/                 Environment validation and cleanup
Jenkinsfile              CI pipeline
playwright.config.ts     Browser projects, reporters and execution policy
```

## Commands

| Command | Purpose |
|---|---|
| `npm test` | Run all projects |
| `npm run test:ui` | Run UI tests |
| `npm run test:api` | Run API tests |
| `npm run test:smoke` | Run tests tagged `@smoke` |
| `npm run test:regression` | Run tests tagged `@regression` |
| `npm run test:chromium` | Run Chromium project |
| `npm run test:headed` | Run with visible browser |
| `npm run test:debug` | Open Playwright Inspector |
| `npm run typecheck` | Strict TypeScript validation |
| `npm run lint` | ESLint |
| `npm run format:check` | Verify formatting |
| `npm run report:allure` | Generate static Allure report |
| `npm run report:open` | Open generated report |
| `npm run report:serve` | Serve a report from `allure-results` |
| `npm run clean` | Remove generated output |

## Environment configuration

Copy `.env.example` to `.env`. Do not commit secrets.

- `BASE_URL`: target URL; defaults to `https://www.saucedemo.com`
- `TEST_USERNAME`: standard user, defaults to `standard_user`
- `TEST_PASSWORD`: demo password, defaults to `secret_sauce`
- `LOCKED_OUT_USERNAME`: defaults to `locked_out_user`
- `API_BASE_URL`: optional API URL; enables the sample API test
- `CI`: CI flag
- `WORKERS`: optional positive worker count; `0` uses Playwright defaults
- `RETRIES`: retry count
- `ACTION_TIMEOUT_MS`, `NAVIGATION_TIMEOUT_MS`: interaction/navigation limits

For private applications, use your CI secret store rather than committing credentials.

## Allure reporting

The Playwright reporter writes raw results to `allure-results/`.

```bash
npm run report:allure
npm run report:open
```

Allure CLI may require a compatible Java runtime. In Jenkins, install/configure the Allure Jenkins plugin and its CLI, then retain `allure-results` as a build artifact.

## Jenkins setup

1. Create a Pipeline job pointing to this repository.
2. Use a Node 20+ Linux agent with permission to install Playwright OS dependencies.
3. Install and configure the Jenkins Allure plugin.
4. Run the pipeline. `BASE_URL` and `API_BASE_URL` are Jenkins parameters.
5. For private apps, bind credentials through Jenkins Credentials Binding and avoid echoing them.

The Jenkinsfile runs Chromium for CI feedback, validates TypeScript and lint, publishes JUnit and Allure results, and archives artifacts. The Allure publisher requires the Jenkins plugin.

## Docker

The Dockerfile uses the Playwright base image matching the declared Playwright version.

```bash
docker build -t playwright-enterprise-framework .
docker run --rm playwright-enterprise-framework
```

## Reliability and security practices

- Keep tests independent and avoid shared mutable state across workers.
- Prefer auto-waiting locators and web-first assertions over arbitrary sleeps.
- Treat retries as a diagnostic safety net, not a way to hide flaky tests.
- Use unique test data and clean up resources created by tests.
- Keep credentials out of source control, logs, screenshots, and Allure attachments.
- Configure artifact retention and access controls.
- Adapt page objects and API contracts if the target application's DOM or behavior changes.

## Verification checklist

```bash
npm install
npx playwright install
npm run validate:env
npm run typecheck
npm run lint
npm run format:check
npx playwright test --project=chromium
npm run report:allure
```

The source files are generated and structurally checked, but a full dependency installation and live browser execution must be performed in your environment. The public demo site can change or be unavailable temporarily.
