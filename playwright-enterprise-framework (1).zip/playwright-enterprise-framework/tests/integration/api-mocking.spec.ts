import { test, expect } from '@playwright/test';

test('the browser can consume a deterministic mocked API response @regression', async ({
  page,
}) => {
  await page.route('**/api/health', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ status: 'ok' }),
    });
  });

  await page.goto('/');
  const response = await page.evaluate(async () => {
    const result = await fetch('/api/health');
    return { status: result.status, body: await result.json() as { status: string } };
  });

  expect(response.status).toBe(200);
  expect(response.body.status).toBe('ok');
});
