import { test, expect } from '../../src/fixtures/test.fixture';

test.describe('Application API @api @regression', () => {
  test('returns a successful health response when API_BASE_URL is configured', async ({
    apiClient,
  }) => {
    test.skip(!apiClient, 'Set API_BASE_URL to run application API tests.');
    const response = await apiClient!.get('/health');
    expect(response.status(), 'health endpoint should return HTTP 200').toBe(200);

    const body: unknown = await response.json();
    expect(body).toBeTruthy();
    expect(typeof body).toBe('object');
  });
});
