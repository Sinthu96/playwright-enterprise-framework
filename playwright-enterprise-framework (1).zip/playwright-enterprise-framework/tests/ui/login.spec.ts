import { env } from '../../config/env';
import { test, expect } from '../../src/fixtures/test.fixture';

test.describe('Sauce Demo authentication @ui @smoke', () => {
  test('standard user can log in and see inventory', async ({ loginPage, inventoryPage }) => {
    await loginPage.openLogin();
    await loginPage.login(env.TEST_USERNAME, env.TEST_PASSWORD);

    await inventoryPage.expectLoaded();
    await expect(inventoryPage.cartLink).toBeVisible();
  });

  test('invalid credentials are rejected', async ({ loginPage, page }) => {
    await loginPage.openLogin();
    await loginPage.login('invalid_user', 'invalid_password');

    await expect(loginPage.errorMessage).toContainText(
      'Username and password do not match any user in this service',
    );
    await expect(page).toHaveURL(/\/$/);
  });

  test('locked-out user cannot log in', async ({ loginPage }) => {
    await loginPage.openLogin();
    await loginPage.login(env.LOCKED_OUT_USERNAME, env.TEST_PASSWORD);

    await expect(loginPage.errorMessage).toContainText(
      'Sorry, this user has been locked out',
    );
  });
});
