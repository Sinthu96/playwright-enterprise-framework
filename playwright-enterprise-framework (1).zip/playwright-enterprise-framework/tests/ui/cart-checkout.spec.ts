import { test, expect } from '../../src/fixtures/test.fixture';

const productName = 'Sauce Labs Backpack';

test.describe('Sauce Demo shopping journey @ui @regression', () => {
  test('user can add a product to cart and verify it', async ({
    loginAsStandardUser,
    inventoryPage,
    cartPage,
    page,
  }) => {
    await loginAsStandardUser();
    await inventoryPage.addProductToCart(productName);
    await expect(inventoryPage.cartBadge).toHaveText('1');

    await inventoryPage.openCart();
    await expect(page).toHaveURL(/cart\.html$/);
    await cartPage.expectContainsProduct(productName);
  });

  test('user can complete checkout', async ({
    loginAsStandardUser,
    inventoryPage,
    cartPage,
    checkoutPage,
    page,
  }) => {
    await loginAsStandardUser();
    await inventoryPage.addProductToCart(productName);
    await inventoryPage.openCart();
    await cartPage.checkout();

    await expect(page).toHaveURL(/checkout-step-one\.html$/);
    await checkoutPage.fillCustomerDetails('Test', 'Customer', '12345');
    await checkoutPage.continueButton.click();

    await expect(page).toHaveURL(/checkout-step-two\.html$/);
    await expect(page.getByTestId('inventory-item')).toContainText(productName);
    await checkoutPage.finishButton.click();
    await checkoutPage.expectOrderComplete();
  });

  test('checkout requires a first name', async ({
    loginAsStandardUser,
    inventoryPage,
    cartPage,
    checkoutPage,
  }) => {
    await loginAsStandardUser();
    await inventoryPage.addProductToCart(productName);
    await inventoryPage.openCart();
    await cartPage.checkout();

    await checkoutPage.fillCustomerDetails('', 'Customer', '12345');
    await checkoutPage.continueButton.click();
    await expect(checkoutPage.errorMessage).toContainText('First Name is required');
  });
});
