// Sauce Demo scenarios are implemented in login.spec.ts and cart-checkout.spec.ts.
export {};
