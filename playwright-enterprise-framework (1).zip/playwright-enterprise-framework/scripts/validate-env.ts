import { env } from '../config/env';

console.log('Environment configuration is valid.');
console.log(`BASE_URL: ${env.BASE_URL}`);
console.log(`API_BASE_URL: ${env.API_BASE_URL ?? '(not configured; API tests will skip)'}`);
console.log(`CI: ${env.CI}`);
console.log(`Workers: ${env.WORKERS ?? 'Playwright default'}`);
