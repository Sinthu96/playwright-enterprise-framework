import { rm } from 'node:fs/promises';

const paths = [
  'test-results',
  'playwright-report',
  'allure-results',
  'allure-report',
  'blob-report',
  'dist',
];

await Promise.all(paths.map((path) => rm(path, { recursive: true, force: true })));
console.log('Generated test artifacts cleaned.');
